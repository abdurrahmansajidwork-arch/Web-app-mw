/**
 * Anonymous device identity helper
 * Document 2, Section 5.1 & 5.7
 */
import { nanoid } from 'nanoid';

const DEVICE_ID_KEY = 'loupe_device_id';

export function getDeviceId(): string {
  if (typeof localStorage === 'undefined') {
    return 'server_test_device';
  }

  let deviceId = localStorage.getItem(DEVICE_ID_KEY);
  if (!deviceId) {
    deviceId = `dev_${nanoid(16)}`;
    localStorage.setItem(DEVICE_ID_KEY, deviceId);
  }
  return deviceId;
}

export function getUser(): { id: string; anonymous: boolean } {
  return {
    id: getDeviceId(),
    anonymous: true,
  };
}
