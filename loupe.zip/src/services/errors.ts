/**
 * Error classes and mapping for Loupe
 * Document 2, Section 5.5 and Document 1, Section 11
 */

export class AppError extends Error {
  code: string;

  constructor(code: string, message?: string) {
    super(message || getErrorMessage(code));
    this.name = 'AppError';
    this.code = code;
  }
}

export const ERROR_MESSAGES: Record<string, string> = {
  // Client pre-check rejections
  too_small: 'Image is too small (minimum 800×300 px).',
  too_large: 'Image file is too large (maximum 10 MB).',
  unsupported_format: 'Unsupported file format. Please upload PNG, JPG, or WEBP.',
  blurry: 'Image is too blurry to extract design tokens accurately.',
  too_many_files: 'Maximum 8 screenshots allowed per run.',
  
  // AI analysis rejections
  not_website: 'The uploaded image does not appear to be a website or web app screenshot.',
  adult_or_unsafe: 'We cannot process this image.',
  unreadable: 'We could not read enough detail from this image. Please send a clearer screenshot.',
  
  // Operational errors
  quota: 'The AI service is currently busy or rate-limited. Please wait a moment and try again.',
  network: 'A network connection error occurred while contacting the service. Please try again.',
  ai_config: 'The AI service is not set up correctly. Check the API key.',
  cancelled: 'Generation was cancelled.',
  storage: 'Could not compress image to fit within storage limits.',
  not_found: 'The requested design result could not be found.',
  firebase_unavailable: 'Remote storage is currently unavailable.',
};

export function getErrorMessage(code: string): string {
  return ERROR_MESSAGES[code] || 'An unexpected error occurred. Please try again.';
}

export function mapError(err: unknown): AppError {
  if (err instanceof AppError) return err;

  const errorObj = err as any;
  const status = errorObj?.status;
  const message = errorObj?.message || '';

  if (status === 429 || status === 503 || message.includes('RESOURCE_EXHAUSTED')) {
    return new AppError('quota');
  }

  if (status === 401 || status === 403 || message.includes('API_KEY_INVALID') || message.includes('PERMISSION_DENIED')) {
    return new AppError('ai_config');
  }

  if (status === 400) {
    return new AppError('unreadable');
  }

  if (message.includes('SAFETY') || message.includes('blocked')) {
    return new AppError('adult_or_unsafe');
  }

  if (message.includes('aborted') || message.includes('cancelled')) {
    return new AppError('cancelled');
  }

  if (err instanceof TypeError || message.includes('fetch') || message.includes('network') || message.includes('timeout')) {
    return new AppError('network');
  }

  return new AppError('network', message || undefined);
}
