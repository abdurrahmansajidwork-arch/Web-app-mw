/**
 * Zod validation schemas and normalization for AnalyzeResult and DesignSpec
 * Document 2, Section 5.1 & Document 1, Section 8
 */
import { z } from 'zod';
import { AnalyzeResult, DesignSpec } from '../types';

export const SiteGroupSchema = z.object({
  id: z.string().default('site-1'),
  label: z.string().default('Untitled Site'),
  description: z.string().default(''),
  sections: z.array(z.string()).default([]),
  imageIndices: z.array(z.number()).default([0]),
});

export const AnalyzeResultSchema = z.object({
  isWebsite: z.boolean().default(true),
  rejectionCode: z.string().nullable().optional(),
  rejectionReason: z.string().nullable().optional(),
  sites: z.array(SiteGroupSchema).default([]),
});

export const ColorTokenSchema = z.object({
  name: z.string().default('Color'),
  value: z.string().default('#000000'),
  token: z.string().default('--color-custom'),
  role: z.string().default('Background or foreground color'),
});

export const TypeScaleItemSchema = z.object({
  role: z.string().default('body'),
  family: z.string().default('Inter'),
  weight: z.union([z.number(), z.string()]).default(400),
  size: z.union([z.number(), z.string()]).default('16px'),
  lineHeight: z.union([z.number(), z.string()]).default('1.5'),
  letterSpacing: z.union([z.number(), z.string()]).default('0em'),
  token: z.string().default('--text-body'),
});

export const TypefaceInfoSchema = z.object({
  name: z.string().default('Inter'),
  substitute: z.string().default('system-ui, sans-serif'),
  role: z.string().default('Primary typeface'),
  weights: z.array(z.union([z.number(), z.string()])).default([400, 600]),
  sizes: z.array(z.union([z.number(), z.string()])).default([14, 16, 24]),
  lineHeight: z.string().default('1.5'),
  letterSpacing: z.string().default('0em'),
  token: z.string().default('--font-primary'),
});

export const SpacingItemSchema = z.object({
  name: z.string().default('base'),
  value: z.string().default('16px'),
  token: z.string().default('--spacing-16'),
});

export const RadiusItemSchema = z.object({
  element: z.string().default('cards'),
  value: z.string().default('16px'),
  token: z.string().optional(),
});

export const ElevationItemSchema = z.object({
  name: z.string().default('subtle'),
  value: z.string().default('rgba(255, 255, 255, 0.12) 0px 0px 0px 1px inset'),
  token: z.string().default('--shadow-subtle'),
});

export const SurfaceItemSchema = z.object({
  level: z.number().default(0),
  name: z.string().default('Obsidian'),
  value: z.string().default('#000000'),
  purpose: z.string().default('Page canvas floor'),
});

export const ComponentSpecSchema = z.object({
  name: z.string().default('Component'),
  role: z.string().default('UI element'),
  description: z.string().default(''),
  props: z.record(z.string(), z.string()).optional(),
  tokensUsed: z.array(z.string()).optional(),
});

export const DesignSpecSchema = z.object({
  meta: z.object({
    title: z.string().max(60).default('Extracted Design System'),
    theme: z.enum(['dark', 'light', 'mixed']).default('dark'),
    industry: z.string().default('ai-tech'),
    styleTags: z.array(z.string()).default(['dark', 'minimal']),
    sections: z.array(z.string()).default(['hero', 'features']),
    summary: z.string().default('Production-grade web interface design system.'),
    description: z.string().default('Extracted design tokens and component specifications.'),
  }),
  colors: z.array(ColorTokenSchema).default([]),
  typography: z.object({
    primaryFont: TypefaceInfoSchema.default({
      name: 'Inter',
      substitute: 'system-ui, sans-serif',
      role: 'Primary brand typeface',
      weights: [400, 600],
      sizes: [14, 16, 24],
      lineHeight: '1.5',
      letterSpacing: '-0.01em',
      token: '--font-primary',
    }),
    secondaryFont: TypefaceInfoSchema.optional(),
    utilityFont: TypefaceInfoSchema.optional(),
    typeScale: z.array(TypeScaleItemSchema).default([]),
  }),
  spacing: z.object({
    baseUnit: z.number().default(4),
    density: z.string().default('comfortable'),
    scale: z.array(SpacingItemSchema).default([]),
    radii: z.array(RadiusItemSchema).default([]),
    shadows: z.array(ElevationItemSchema).default([]),
    layout: z.object({
      pageMaxWidth: z.string().default('1200px'),
      sectionGap: z.string().default('80px'),
      cardPadding: z.string().default('24px'),
      elementGap: z.string().default('20px'),
    }),
  }),
  surfaces: z.array(SurfaceItemSchema).default([]),
  components: z.array(ComponentSpecSchema).default([]),
  dosAndDonts: z.object({
    dos: z.array(z.string()).default([]),
    donts: z.array(z.string()).default([]),
  }),
});

export function normalizeDesignSpec(spec: DesignSpec): DesignSpec {
  // Normalize colors to uppercase hex
  spec.colors = spec.colors.map(c => {
    let val = c.value.trim();
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...c, value: val };
  });

  // Normalize surfaces to uppercase hex
  spec.surfaces = spec.surfaces.map(s => {
    let val = s.value.trim();
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...s, value: val };
  });

  // Ensure title is trimmed to 60 chars max
  spec.meta.title = spec.meta.title.trim().slice(0, 60);

  return spec;
}

export function validateDesignSpec(data: unknown): { success: boolean; data?: DesignSpec; errors?: string[] } {
  const result = DesignSpecSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: normalizeDesignSpec(result.data) };
  } else {
    const errors = result.error.issues.map(e => `${e.path.join('.')}: ${e.message}`);
    return { success: false, errors };
  }
}

export function validateAnalyzeResult(data: unknown): { success: boolean; data?: AnalyzeResult; errors?: string[] } {
  const result = AnalyzeResultSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  } else {
    const errors = result.error.issues.map(e => `${e.path.join('.')}: ${e.message}`);
    return { success: false, errors };
  }
}
