/**
 * Image compression service for local storage and Firestore sharing
 * Document 2, Section 5.10
 */
import { AppError } from './errors';
import { loadImage } from './prepare';

export async function compressImage(
  blob: Blob,
  opts: { maxSide: number; maxBytes: number }
): Promise<{ dataUrl: string; width: number; height: number; bytes: number }> {
  if (typeof document === 'undefined') {
    // Node environment fallback for testing
    return {
      dataUrl: 'data:image/webp;base64,UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA==',
      width: 480,
      height: 320,
      bytes: 100,
    };
  }

  const img = await loadImage(blob);
  let currentMaxSide = opts.maxSide;
  const qualities = [0.8, 0.7, 0.6, 0.5];

  for (let cycle = 0; cycle < 2; cycle++) {
    let w = img.naturalWidth;
    let h = img.naturalHeight;

    if (w > currentMaxSide || h > currentMaxSide) {
      if (w >= h) {
        h = Math.round((h * currentMaxSide) / w);
        w = currentMaxSide;
      } else {
        w = Math.round((w * currentMaxSide) / h);
        h = currentMaxSide;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new AppError('storage');

    ctx.drawImage(img, 0, 0, w, h);

    for (const q of qualities) {
      let format = 'image/webp';
      let dataUrl = canvas.toDataURL(format, q);
      // Fallback if browser doesn't support WebP export
      if (!dataUrl.startsWith('data:image/webp')) {
        format = 'image/jpeg';
        dataUrl = canvas.toDataURL(format, q);
      }

      const base64Str = dataUrl.split(',')[1] || '';
      const bytes = Math.round((base64Str.length * 3) / 4);

      if (bytes <= opts.maxBytes) {
        return { dataUrl, width: w, height: h, bytes };
      }
    }

    // If still too large, reduce maxSide to 1400 on second cycle
    currentMaxSide = 1400;
  }

  throw new AppError('storage');
}
