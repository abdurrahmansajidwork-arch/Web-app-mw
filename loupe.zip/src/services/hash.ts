/**
 * SHA-256 helpers for deterministic caching
 * Document 2, Section 5.1 & 5.5
 */
import { PIPELINE_VERSION } from '../config';

export async function computeFilesHash(files: File[]): Promise<string> {
  const buffers: Uint8Array[] = [];
  let totalLength = 0;

  for (const file of files) {
    const arrayBuffer = await file.arrayBuffer();
    const uint8 = new Uint8Array(arrayBuffer);
    buffers.push(uint8);
    totalLength += uint8.length;
  }

  // Concatenate all bytes in order
  const combined = new Uint8Array(totalLength);
  let offset = 0;
  for (const buf of buffers) {
    combined.set(buf, offset);
    offset += buf.length;
  }

  // Web Crypto API in browser / Node crypto in tests
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', combined);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } else {
    // Node environment fallback for unit tests
    const nodeCrypto = await import('node:crypto');
    return nodeCrypto.createHash('sha256').update(combined).digest('hex');
  }
}

export function makeCacheKey(hash: string): string {
  return `loupe_v${PIPELINE_VERSION}_${hash}`;
}
