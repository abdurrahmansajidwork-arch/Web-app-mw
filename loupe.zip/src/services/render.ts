/**
 * Markdown renderer from DesignSpec to DESIGN.md
 * Document 2, Section 0, 5.8 & 5.9
 */
import { DesignSpec } from '../types';

export function esc(text: string | number | undefined | null): string {
  if (text === undefined || text === null) return '-';
  const str = String(text).replace(/\|/g, '\\|').replace(/[\r\n]+/g, ' ').trim();
  return str.length > 0 ? str : '-';
}

export function hex(v: string | undefined | null): string {
  if (!v) return '`-`';
  let str = String(v).trim();
  if (!str.startsWith('#')) str = `#${str}`;
  return `\`${str.toUpperCase()}\``;
}

export function formatPx(n: number | string | undefined | null): string {
  if (n === undefined || n === null || n === '') return '-';
  const num = typeof n === 'number' ? n : parseFloat(String(n));
  if (isNaN(num)) return esc(n);
  return `${Math.round(num)}px`;
}

export function formatEm(n: number | string | undefined | null): string {
  if (n === undefined || n === null || n === '') return '-';
  const num = typeof n === 'number' ? n : parseFloat(String(n));
  if (isNaN(num)) return esc(n);
  return `${num.toFixed(2)}em`;
}

export function slug(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .slice(0, 40);
}

export function renderDesignMd(spec: DesignSpec): string {
  const title = spec.meta.title.trim().slice(0, 60);
  const lines: string[] = [];

  // 1. Title line
  lines.push(`# DESIGN.md: ${title}`);
  lines.push(`> ${spec.meta.summary || 'Extracted design system specification'}`);
  lines.push('');
  lines.push(`**Theme:** ${spec.meta.theme}`);
  if (spec.meta.description) {
    lines.push('');
    lines.push(spec.meta.description);
  }
  lines.push('');

  // 2. Style Summary
  lines.push('## Style Summary');
  lines.push('');
  lines.push(`- **Industry:** ${spec.meta.industry}`);
  lines.push(`- **Visual Style:** ${spec.meta.styleTags.join(', ')}`);
  lines.push(`- **Identified Sections:** ${spec.meta.sections.join(', ')}`);
  lines.push('');

  // 3. Tokens — Colors
  lines.push('## Tokens — Colors');
  lines.push('');
  lines.push('| Name | Value | Token | Role |');
  lines.push('|---|---|---|---|');
  for (const c of spec.colors) {
    lines.push(`| ${esc(c.name)} | ${hex(c.value)} | \`${esc(c.token)}\` | ${esc(c.role)} |`);
  }
  lines.push('');

  // 4. Tokens — Typography
  lines.push('## Tokens — Typography');
  lines.push('');
  const pFont = spec.typography.primaryFont;
  lines.push(`### Primary Typeface: ${esc(pFont.name)}`);
  lines.push(`- **Substitute:** ${esc(pFont.substitute)}`);
  lines.push(`- **Role:** ${esc(pFont.role)}`);
  lines.push(`- **Weights:** ${pFont.weights.map(w => esc(w)).join(', ')}`);
  lines.push(`- **Token:** \`${esc(pFont.token)}\``);
  lines.push('');

  if (spec.typography.utilityFont) {
    const uFont = spec.typography.utilityFont;
    lines.push(`### Utility / Monospace Typeface: ${esc(uFont.name)}`);
    lines.push(`- **Substitute:** ${esc(uFont.substitute)}`);
    lines.push(`- **Role:** ${esc(uFont.role)}`);
    lines.push(`- **Weights:** ${uFont.weights.map(w => esc(w)).join(', ')}`);
    lines.push(`- **Token:** \`${esc(uFont.token)}\``);
    lines.push('');
  }

  lines.push('### Type Scale');
  lines.push('');
  lines.push('| Role | Family | Weight | Size | Line Height | Letter Spacing | Token |');
  lines.push('|---|---|---|---|---|---|---|');
  for (const t of spec.typography.typeScale) {
    const sizeStr = typeof t.size === 'number' ? formatPx(t.size) : esc(t.size);
    lines.push(
      `| ${esc(t.role)} | ${esc(t.family)} | ${esc(t.weight)} | ${sizeStr} | ${esc(t.lineHeight)} | ${esc(t.letterSpacing)} | \`${esc(t.token)}\` |`
    );
  }
  lines.push('');

  // 5. Tokens — Spacing & Shapes
  lines.push('## Tokens — Spacing & Shapes');
  lines.push('');
  lines.push(`- **Base unit:** ${spec.spacing.baseUnit}px`);
  lines.push(`- **Density:** ${spec.spacing.density}`);
  lines.push('');

  lines.push('### Spacing Scale');
  lines.push('');
  lines.push('| Name | Value | Token |');
  lines.push('|---|---|---|');
  for (const s of spec.spacing.scale) {
    lines.push(`| ${esc(s.name)} | ${esc(s.value)} | \`${esc(s.token)}\` |`);
  }
  lines.push('');

  lines.push('### Border Radius');
  lines.push('');
  lines.push('| Element | Value |');
  lines.push('|---|---|');
  for (const r of spec.spacing.radii) {
    lines.push(`| ${esc(r.element)} | ${esc(r.value)} |`);
  }
  lines.push('');

  lines.push('### Elevation & Shadows');
  lines.push('');
  lines.push('| Name | Value | Token |');
  lines.push('|---|---|---|');
  for (const e of spec.spacing.shadows) {
    lines.push(`| ${esc(e.name)} | \`${esc(e.value)}\` | \`${esc(e.token)}\` |`);
  }
  lines.push('');

  lines.push('### Layout');
  lines.push('');
  lines.push(`- **Page max-width:** ${spec.spacing.layout.pageMaxWidth}`);
  lines.push(`- **Section gap:** ${spec.spacing.layout.sectionGap}`);
  lines.push(`- **Card padding:** ${spec.spacing.layout.cardPadding}`);
  lines.push(`- **Element gap:** ${spec.spacing.layout.elementGap}`);
  lines.push('');

  // 6. Surfaces
  lines.push('## Surfaces');
  lines.push('');
  lines.push('| Level | Name | Value | Purpose |');
  lines.push('|---|---|---|---|');
  for (const surf of spec.surfaces) {
    lines.push(`| ${surf.level} | ${esc(surf.name)} | ${hex(surf.value)} | ${esc(surf.purpose)} |`);
  }
  lines.push('');

  // 7. Components
  lines.push('## Components');
  lines.push('');
  for (const comp of spec.components) {
    lines.push(`### ${esc(comp.name)}`);
    lines.push(`**Role:** ${esc(comp.role)}`);
    lines.push('');
    lines.push(esc(comp.description));
    if (comp.props && Object.keys(comp.props).length > 0) {
      lines.push('');
      lines.push('**Properties:**');
      for (const [k, v] of Object.entries(comp.props)) {
        lines.push(`- **${k}:** ${esc(v)}`);
      }
    }
    lines.push('');
  }

  // 8. Do's and Don'ts
  lines.push("## Do's and Don'ts");
  lines.push('');
  lines.push('### Do');
  for (const item of spec.dosAndDonts.dos) {
    lines.push(`- ${esc(item)}`);
  }
  lines.push('');
  lines.push("### Don't");
  for (const item of spec.dosAndDonts.donts) {
    lines.push(`- ${esc(item)}`);
  }
  lines.push('');

  return lines.join('\n');
}
