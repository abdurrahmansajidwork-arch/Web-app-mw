/**
 * Image preparation, decoding, thumbnail generation, and blur checking
 * Document 2, Section 4.2 & 5.1
 */
import {
  MIN_WIDTH,
  MIN_HEIGHT,
  MAX_DIM,
  MAX_FILE_MB,
  BLUR_THRESHOLD,
  AI_MAX_SIDE,
  AI_JPEG_QUALITY,
} from '../config';

export interface PreparedImage {
  file: File;
  width: number;
  height: number;
  thumbDataUrl: string;
  dataUrl: string;
  aiBase64: string;
  blurScore: number;
  issueCode?: string;
  issueReason?: string;
}

export async function validateClientFile(file: File): Promise<{ valid: boolean; code?: string; reason?: string }> {
  // 1. File size check
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    return {
      valid: false,
      code: 'too_large',
      reason: `File size exceeds ${MAX_FILE_MB} MB.`,
    };
  }

  // 2. MIME type check
  const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
  if (!validTypes.includes(file.type)) {
    return {
      valid: false,
      code: 'unsupported_format',
      reason: 'Only PNG, JPG, and WEBP formats are supported.',
    };
  }

  return { valid: true };
}

export function loadImage(file: File | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image'));
    };
    img.src = url;
  });
}

/**
 * Calculates variance of Laplacian on a 512px downscaled grayscale canvas.
 * Threshold is BLUR_THRESHOLD (40).
 */
export function calculateBlurScore(img: HTMLImageElement): number {
  if (typeof document === 'undefined') return 100; // In pure Node test environment

  const targetDim = 512;
  const scale = Math.min(targetDim / img.naturalWidth, targetDim / img.naturalHeight, 1);
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return 100;

  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Grayscale representation
  const gray = new Float32Array(w * h);
  for (let i = 0; i < data.length; i += 4) {
    gray[i / 4] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
  }

  // Discrete Laplacian convolution
  // Kernel: [0, 1, 0], [1, -4, 1], [0, 1, 0]
  let sum = 0;
  let sumSq = 0;
  let count = 0;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = y * w + x;
      const lap =
        gray[idx - w] +
        gray[idx + w] +
        gray[idx - 1] +
        gray[idx + 1] -
        4 * gray[idx];
      sum += lap;
      sumSq += lap * lap;
      count++;
    }
  }

  if (count === 0) return 100;
  const mean = sum / count;
  const variance = sumSq / count - mean * mean;
  return Math.round(variance * 10) / 10;
}

/**
 * Creates 160px wide thumbnail for upload tiles
 */
export function createThumbnail(img: HTMLImageElement): string {
  if (typeof document === 'undefined') return '';
  const canvas = document.createElement('canvas');
  const targetW = 160;
  const scale = targetW / img.naturalWidth;
  const targetH = Math.max(1, Math.round(img.naturalHeight * scale));

  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.drawImage(img, 0, 0, targetW, targetH);
  return canvas.toDataURL('image/jpeg', 0.85);
}

/**
 * Prepares image for AI input (resized to maxSide 2048, quality 0.9 JPEG)
 */
export function prepareAiImage(img: HTMLImageElement, maxSide: number = AI_MAX_SIDE): { base64: string; dataUrl: string } {
  if (typeof document === 'undefined') return { base64: '', dataUrl: '' };

  const nw = img.naturalWidth;
  const nh = img.naturalHeight;
  let w = nw;
  let h = nh;

  if (w > maxSide || h > maxSide) {
    if (w >= h) {
      h = Math.round((h * maxSide) / w);
      w = maxSide;
    } else {
      w = Math.round((w * maxSide) / h);
      h = maxSide;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return { base64: '', dataUrl: '' };

  ctx.drawImage(img, 0, 0, w, h);
  const dataUrl = canvas.toDataURL('image/jpeg', AI_JPEG_QUALITY);
  const base64 = dataUrl.replace(/^data:image\/[a-z]+;base64,/, '');

  return { base64, dataUrl };
}

export async function processUploadFile(file: File): Promise<PreparedImage> {
  const clientCheck = await validateClientFile(file);
  if (!clientCheck.valid) {
    return {
      file,
      width: 0,
      height: 0,
      thumbDataUrl: '',
      dataUrl: '',
      aiBase64: '',
      blurScore: 0,
      issueCode: clientCheck.code,
      issueReason: clientCheck.reason,
    };
  }

  const img = await loadImage(file);
  const width = img.naturalWidth;
  const height = img.naturalHeight;

  // Dimension checks
  if (width < MIN_WIDTH || height < MIN_HEIGHT) {
    return {
      file,
      width,
      height,
      thumbDataUrl: createThumbnail(img),
      dataUrl: '',
      aiBase64: '',
      blurScore: 0,
      issueCode: 'too_small',
      issueReason: `Image is too small (${width}×${height}px). Minimum is ${MIN_WIDTH}×${MIN_HEIGHT}px.`,
    };
  }

  if (width > MAX_DIM || height > MAX_DIM) {
    return {
      file,
      width,
      height,
      thumbDataUrl: createThumbnail(img),
      dataUrl: '',
      aiBase64: '',
      blurScore: 0,
      issueCode: 'too_large',
      issueReason: `Image dimension exceeds maximum allowed (${MAX_DIM}px).`,
    };
  }

  // Blur check
  const blurScore = calculateBlurScore(img);
  if (blurScore < BLUR_THRESHOLD) {
    return {
      file,
      width,
      height,
      thumbDataUrl: createThumbnail(img),
      dataUrl: '',
      aiBase64: '',
      blurScore,
      issueCode: 'blurry',
      issueReason: `Image is too blurry to extract accurate details (score ${blurScore} / min ${BLUR_THRESHOLD}).`,
    };
  }

  const thumbDataUrl = createThumbnail(img);
  const { base64: aiBase64, dataUrl } = prepareAiImage(img, AI_MAX_SIDE);

  return {
    file,
    width,
    height,
    thumbDataUrl,
    dataUrl,
    aiBase64,
    blurScore,
  };
}
