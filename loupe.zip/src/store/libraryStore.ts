/**
 * Library store for browsing, searching, and filtering public prompts
 * Document 2, Section 4.8 & 5.6
 */
import { create } from 'zustand';
import { ShareDoc } from '../types';
import { listPublic } from '../storage/remote';
import { LIBRARY_FIRST_PAGE, LIBRARY_PAGE } from '../config';

export interface LibraryFilters {
  industry: string[];
  style: string[];
  sections: string[];
}

interface LibraryState {
  items: (ShareDoc & { id: string })[];
  cursor: any;
  sort: 'new' | 'copied';
  filters: LibraryFilters;
  search: string;
  status: 'idle' | 'loading' | 'error';
  hasMore: boolean;

  // Actions
  loadInitial: () => Promise<void>;
  loadMore: () => Promise<void>;
  setSearch: (query: string) => void;
  setSort: (sort: 'new' | 'copied') => void;
  toggleFilter: (group: keyof LibraryFilters, value: string) => void;
  clearFilters: () => void;
}

export const useLibraryStore = create<LibraryState>((set, get) => ({
  items: [],
  cursor: null,
  sort: 'new',
  filters: {
    industry: [],
    style: [],
    sections: [],
  },
  search: '',
  status: 'idle',
  hasMore: true,

  loadInitial: async () => {
    set({ status: 'loading' });
    try {
      const res = await listPublic({
        sort: get().sort,
        pageSize: LIBRARY_FIRST_PAGE,
      });
      set({
        items: res.items,
        cursor: res.nextCursor,
        hasMore: res.hasMore,
        status: 'idle',
      });
    } catch (err) {
      console.warn('Library load error:', err);
      set({ status: 'error' });
    }
  },

  loadMore: async () => {
    const { cursor, sort, items, hasMore, status } = get();
    if (!hasMore || status === 'loading') return;

    set({ status: 'loading' });
    try {
      const res = await listPublic({
        sort,
        pageSize: LIBRARY_PAGE,
        cursor,
      });
      set({
        items: [...items, ...res.items],
        cursor: res.nextCursor,
        hasMore: res.hasMore,
        status: 'idle',
      });
    } catch (err) {
      console.warn('Library loadMore error:', err);
      set({ status: 'error' });
    }
  },

  setSearch: (search) => {
    set({ search });
  },

  setSort: (sort) => {
    set({ sort });
    get().loadInitial();
  },

  toggleFilter: (group, value) => {
    const { filters } = get();
    const current = filters[group];
    const exists = current.includes(value);
    const updated = exists ? current.filter(v => v !== value) : [...current, value];
    set({
      filters: {
        ...filters,
        [group]: updated,
      },
    });
  },

  clearFilters: () => {
    set({
      filters: {
        industry: [],
        style: [],
        sections: [],
      },
      search: '',
    });
  },
}));
