# DESIGN.md: Aeline: AI Consulting Landing
> High-touch AI advisory and systems engineering

**Theme:** dark

Architectural monochrome design system for high-trust AI systems engineering.

## Style Summary

- **Industry:** ai-tech
- **Visual Style:** dark, minimal
- **Identified Sections:** hero, features, pricing

## Tokens — Colors

| Name | Value | Token | Role |
|---|---|---|---|
| Signal Blue | `#0063E1` | `--color-signal-blue` | Primary CTA fill and active indicators |
| Obsidian | `#000000` | `--color-obsidian` | Main canvas floor |
| Carbon | `#040910` | `--color-carbon` | Elevated card panels |
| Ash | `#858585` | `--color-ash` | Muted secondary labels and body copy |
| Paper | `#FFFFFF` | `--color-paper` | Headings and primary text |

## Tokens — Typography

### Primary Typeface: Inter
- **Substitute:** system-ui, -apple-system, sans-serif
- **Role:** Headlines and body copy
- **Weights:** 400, 600
- **Token:** `--font-primary`

### Utility / Monospace Typeface: JetBrains Mono
- **Substitute:** monospace
- **Role:** Code tokens, data badges, and metrics
- **Weights:** 400
- **Token:** `--font-mono`

### Type Scale

| Role | Family | Weight | Size | Line Height | Letter Spacing | Token |
|---|---|---|---|---|---|---|
| display | Inter | 400 | 86px | 1.0 | -0.064em | `--text-display` |
| heading | Inter | 400 | 24px | 1.33 | -0.027em | `--text-heading` |
| body | Inter | 400 | 16px | 1.5 | -0.007em | `--text-body` |

## Tokens — Spacing & Shapes

- **Base unit:** 4px
- **Density:** comfortable

### Spacing Scale

| Name | Value | Token |
|---|---|---|
| 4 | 4px | `--spacing-4` |
| 8 | 8px | `--spacing-8` |
| 16 | 16px | `--spacing-16` |
| 24 | 24px | `--spacing-24` |

### Border Radius

| Element | Value |
|---|---|
| buttons | 59px |
| cards | 16px |
| inputs | 8px |

### Elevation & Shadows

| Name | Value | Token |
|---|---|---|
| subtle | `rgba(255, 255, 255, 0.12) 0px 0px 0px 1px inset` | `--shadow-subtle` |

### Layout

- **Page max-width:** 1200px
- **Section gap:** 80px
- **Card padding:** 24px
- **Element gap:** 20px

## Surfaces

| Level | Name | Value | Purpose |
|---|---|---|---|
| 0 | Obsidian | `#000000` | Page background floor |
| 1 | Carbon | `#040910` | First card elevation |

## Components

### Primary CTA Button
**Role:** Singular conversion button

Pill-shaped button with Signal Blue #0063E1 fill and white text.

**Properties:**
- **padding:** 14px 28px
- **radius:** 59px

## Do's and Don'ts

### Do
- Use #0063E1 exclusively for the primary CTA per viewport
- Communicate elevation through 1px inset border rather than drop shadows

### Don't
- Never introduce secondary chromatic colors (green, red, orange)
- Never use bold weights on large display headlines
