/**
 * Unit tests for pure logic
 * Ultra Mode Section 3
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

import { validateDesignSpec, validateAnalyzeResult } from '../services/validate';
import { renderDesignMd, slug, esc, hex, formatPx } from '../services/render';
import { makeCacheKey } from '../services/hash';
import { mapError, AppError } from '../services/errors';
import { DesignSpec } from '../types';

test('slug helper formats titles correctly', () => {
  assert.equal(slug('Aeline: AI Consulting Landing'), 'aeline-ai-consulting-landing');
  assert.equal(slug('Northfield: Fintech Pricing Page!'), 'northfield-fintech-pricing-page');
  assert.equal(slug('   leading and trailing spaces   '), 'leading-and-trailing-spaces');
});

test('esc helper escapes pipes and replaces newlines', () => {
  assert.equal(esc('First | Second'), 'First \\| Second');
  assert.equal(esc('Line 1\nLine 2'), 'Line 1 Line 2');
  assert.equal(esc(''), '-');
  assert.equal(esc(null), '-');
});

test('hex helper ensures uppercase hex wrapped in backticks', () => {
  assert.equal(hex('#0063e1'), '`#0063E1`');
  assert.equal(hex('0063e1'), '`#0063E1`');
  assert.equal(hex(null), '`-`');
});

test('formatPx helper formats numbers correctly', () => {
  assert.equal(formatPx(16), '16px');
  assert.equal(formatPx('24'), '24px');
  assert.equal(formatPx(null), '-');
});

test('makeCacheKey generates versioned key', () => {
  assert.equal(makeCacheKey('abcdef123456'), 'loupe_v1.0.0_abcdef123456');
});

test('mapError correctly identifies error codes', () => {
  assert.equal(mapError({ status: 429 }).code, 'quota');
  assert.equal(mapError({ status: 503 }).code, 'quota');
  assert.equal(mapError({ status: 401 }).code, 'ai_config');
  assert.equal(mapError({ status: 403 }).code, 'ai_config');
  assert.equal(mapError(new Error('cancelled')).code, 'cancelled');
  assert.equal(mapError(new AppError('not_website')).code, 'not_website');
});

test('validateAnalyzeResult validates and parses correctly', () => {
  const validData = {
    isWebsite: true,
    sites: [
      {
        id: 'site-1',
        label: 'Aeline: AI Consulting',
        description: 'Landing page',
        sections: ['hero', 'pricing'],
        imageIndices: [0],
      },
    ],
  };

  const res = validateAnalyzeResult(validData);
  assert.equal(res.success, true);
  assert.equal(res.data?.sites.length, 1);
  assert.equal(res.data?.sites[0].label, 'Aeline: AI Consulting');
});

test('renderDesignMd produces byte-accurate match with sample-design.md fixture', () => {
  const fixtureSpecPath = path.resolve('src/tests/fixtures/sample-spec.json');
  const fixtureMdPath = path.resolve('src/tests/fixtures/sample-design.md');

  const rawSpec = JSON.parse(fs.readFileSync(fixtureSpecPath, 'utf-8'));
  const expectedMd = fs.readFileSync(fixtureMdPath, 'utf-8').trim();

  const validated = validateDesignSpec(rawSpec);
  assert.equal(validated.success, true);

  const renderedMd = renderDesignMd(validated.data as DesignSpec).trim();
  assert.equal(renderedMd, expectedMd);
});
