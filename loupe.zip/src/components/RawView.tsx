/**
 * Raw markdown viewer with unselectable line numbers
 * Document 2, Section 4.6 & 5.8
 */
import React from 'react';

interface RawViewProps {
  content: string;
}

export const RawView: React.FC<RawViewProps> = ({ content }) => {
  const lines = content.split('\n');

  return (
    <div className="bg-[#040910] rounded-[16px] inset-border p-4 overflow-x-auto text-left font-mono text-xs leading-relaxed">
      <div className="grid grid-cols-[auto_1fr] gap-x-4 min-w-full">
        {/* Line Numbers Column (Unselectable) */}
        <div className="select-none text-[#858585]/40 text-right pr-2 border-r border-[rgba(255,255,255,0.08)]">
          {lines.map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        {/* Code Content Column */}
        <div className="text-white select-text whitespace-pre overflow-x-auto">
          {lines.map((line, i) => (
            <div key={i}>{line || '\u00A0'}</div>
          ))}
        </div>
      </div>
    </div>
  );
};
