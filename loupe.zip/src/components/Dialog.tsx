/**
 * Accessible modal dialog component
 * Document 2, Section 4.7 & 5.14
 */
import React, { useEffect, useRef } from 'react';

interface DialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: React.ReactNode;
}

export const Dialog: React.FC<DialogProps> = ({
  isOpen,
  onClose,
  title,
  description,
  children,
}) => {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dialog-title"
    >
      <div
        ref={dialogRef}
        className="w-full max-w-md bg-[#0d0d0d] border border-[rgba(255,255,255,0.12)] rounded-[16px] p-6 shadow-2xl transition-all"
      >
        <h2 id="dialog-title" className="text-lg font-medium text-white mb-2">
          {title}
        </h2>
        {description && (
          <p className="text-sm text-[#858585] mb-6 leading-relaxed">
            {description}
          </p>
        )}
        {children}
      </div>
    </div>
  );
};
