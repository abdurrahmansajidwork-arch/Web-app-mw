/**
 * Markdown preview component with react-markdown and remark-gfm
 * Document 2, Section 4.6 & 5.8
 */
import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MarkdownViewProps {
  content: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content }) => {
  return (
    <div className="prose prose-invert max-w-none text-left">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => (
            <h1 className="text-2xl font-normal text-white tracking-[-0.027em] pb-3 border-b border-[rgba(255,255,255,0.08)] mb-6">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-xl font-normal text-white tracking-[-0.027em] mt-8 mb-4 pb-2 border-b border-[rgba(255,255,255,0.08)]">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-base font-medium text-white tracking-[-0.015em] mt-6 mb-2">
              {children}
            </h3>
          ),
          p: ({ children }) => (
            <p className="text-sm text-[#858585] leading-relaxed mb-4">
              {children}
            </p>
          ),
          blockquote: ({ children }) => (
            <blockquote className="border-l-2 border-[#0063e1] pl-4 italic text-sm text-[#858585] my-4">
              {children}
            </blockquote>
          ),
          ul: ({ children }) => (
            <ul className="list-disc list-inside text-sm text-[#858585] mb-4 space-y-1">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal list-inside text-sm text-[#858585] mb-4 space-y-1">
              {children}
            </ol>
          ),
          code: ({ children, className }) => {
            const isInline = !className;
            return isInline ? (
              <code className="bg-[#1f1f1f] text-white font-mono text-[13px] px-1.5 py-0.5 rounded-[4px]">
                {children}
              </code>
            ) : (
              <code className="text-xs font-mono text-white">{children}</code>
            );
          },
          pre: ({ children }) => (
            <pre className="bg-[#040910] p-4 rounded-[12px] inset-border overflow-x-auto text-xs font-mono text-white my-4 leading-relaxed">
              {children}
            </pre>
          ),
          table: ({ children }) => (
            <div className="overflow-x-auto my-6 rounded-[12px] inset-border bg-[#040910]">
              <table className="w-full text-left text-xs border-collapse">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-[#0d0d0d] md:sticky md:top-0 z-10 border-b border-[rgba(255,255,255,0.08)]">
              {children}
            </thead>
          ),
          th: ({ children }) => (
            <th className="px-4 py-3 font-medium text-white min-w-[96px] whitespace-nowrap">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="px-4 py-3 border-b border-[rgba(255,255,255,0.04)] text-[#858585] min-w-[96px] break-words">
              {children}
            </td>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
};
