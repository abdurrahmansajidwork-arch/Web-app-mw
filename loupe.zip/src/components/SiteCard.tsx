/**
 * Multi-site selection card
 * Document 2, Section 4.3
 */
import React from 'react';
import { SiteGroup } from '../types';

interface SiteCardProps {
  site: SiteGroup;
  selected: boolean;
  onSelect: () => void;
  thumbnails: string[];
}

export const SiteCard: React.FC<SiteCardProps> = ({
  site,
  selected,
  onSelect,
  thumbnails,
}) => {
  return (
    <div
      data-testid={`site-card-${site.id}`}
      onClick={onSelect}
      className={`p-6 rounded-[16px] bg-[#0d0d0d] inset-border cursor-pointer transition-all flex flex-col gap-4 ${
        selected
          ? 'border-[#0063e1] ring-1 ring-[#0063e1]'
          : 'hover:border-[rgba(255,255,255,0.2)]'
      }`}
    >
      <div className="flex items-start gap-4">
        {/* Radio Indicator */}
        <div className="mt-1 flex items-center justify-center">
          <input
            type="radio"
            name="site-selection"
            checked={selected}
            onChange={onSelect}
            className="w-4 h-4 accent-[#0063e1] cursor-pointer"
          />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col gap-1">
          <h3 className="text-base font-medium text-white tracking-[-0.015em]">
            {site.label}
          </h3>
          {site.description && (
            <p className="text-sm text-[#858585]">{site.description}</p>
          )}

          {/* Section tags */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {site.sections.map((sec) => (
              <span
                key={sec}
                className="bg-[#1f1f1f] text-[#858585] text-xs font-mono px-2 py-0.5 rounded-[4px]"
              >
                {sec}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Thumbnails of images belonging to this site */}
      <div className="flex items-center gap-2 pl-8 overflow-x-auto py-1">
        {site.imageIndices.map((idx) => {
          const thumb = thumbnails[idx];
          if (!thumb) return null;
          return (
            <div
              key={idx}
              className="w-16 h-16 rounded-[8px] bg-[#040910] inset-border overflow-hidden shrink-0 flex items-center justify-center"
            >
              <img
                src={thumb}
                alt={`Site preview ${idx + 1}`}
                className="w-full h-full object-contain"
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
