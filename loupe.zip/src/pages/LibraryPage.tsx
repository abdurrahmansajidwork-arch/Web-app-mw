/**
 * S9 Community Library Page
 * Document 2, Section 4.8
 */
import React, { useEffect, useMemo } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { useLibraryStore } from '../store/libraryStore';
import { INDUSTRY_TAGS, STYLE_TAGS, SECTION_TAGS } from '../config';
import { TagChip } from '../components/TagChip';
import { LibraryCard } from '../components/LibraryCard';

export const LibraryPage: React.FC = () => {
  const {
    items,
    sort,
    filters,
    search,
    status,
    hasMore,
    loadInitial,
    loadMore,
    setSearch,
    setSort,
    toggleFilter,
    clearFilters,
  } = useLibraryStore();

  useEffect(() => {
    loadInitial();
  }, [loadInitial]);

  const hasActiveFilters =
    filters.industry.length > 0 ||
    filters.style.length > 0 ||
    filters.sections.length > 0 ||
    search.trim().length > 0;

  // Filter items in memory according to search and multi-select filters
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // 1. Search query (case-insensitive over title and all tags)
      if (search.trim()) {
        const query = search.toLowerCase();
        const allItemTags = [
          ...(item.tags.industry || []),
          ...(item.tags.style || []),
          ...(item.tags.sections || []),
        ].map((t) => t.toLowerCase());
        const matchTitle = item.title.toLowerCase().includes(query);
        const matchTag = allItemTags.some((t) => t.includes(query));
        if (!matchTitle && !matchTag) return false;
      }

      // 2. Industry filter (multi-select within group: match any)
      if (filters.industry.length > 0) {
        const itemIndustries = item.tags.industry || [];
        const hasAny = filters.industry.some((val) => itemIndustries.includes(val));
        if (!hasAny) return false;
      }

      // 3. Style filter (multi-select within group: match any)
      if (filters.style.length > 0) {
        const itemStyles = item.tags.style || [];
        const hasAny = filters.style.some((val) => itemStyles.includes(val));
        if (!hasAny) return false;
      }

      // 4. Sections filter (multi-select within group: match any)
      if (filters.sections.length > 0) {
        const itemSections = item.tags.sections || [];
        const hasAny = filters.sections.some((val) => itemSections.includes(val));
        if (!hasAny) return false;
      }

      return true;
    });
  }, [items, search, filters]);

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-12 flex flex-col gap-8 text-left">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-normal text-white tracking-[-0.027em]">
          Community Library
        </h1>
        <p className="text-sm text-[#858585]">
          Browse, inspect, and copy production-tested design systems shared by the community.
        </p>
      </div>

      {/* Search and Sort controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#858585] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            data-testid="library-search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search prompts by title or tags..."
            className="w-full bg-[#1f1f1f] text-white placeholder-[#858585] text-xs font-mono pl-10 pr-4 py-2.5 rounded-[8px] inset-border focus:outline-none focus:ring-1 focus:ring-[#0063e1] transition-all"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-[#858585] font-mono">Sort:</span>
          <select
            data-testid="library-sort"
            value={sort}
            onChange={(e) => setSort(e.target.value as 'new' | 'copied')}
            className="bg-[#1f1f1f] text-white text-xs font-mono px-3 py-2 rounded-[8px] inset-border cursor-pointer focus:outline-none"
          >
            <option value="new">Newest</option>
            <option value="copied">Most Copied</option>
          </select>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={clearFilters}
              className="text-xs text-[#858585] hover:text-white underline ml-3 cursor-pointer"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Filter Chips Groups */}
      <div className="flex flex-col gap-3 p-4 rounded-[16px] bg-[#0d0d0d] inset-border">
        {/* Industry */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-[#858585] font-mono w-20 shrink-0">Industry:</span>
          <div className="flex flex-wrap gap-1.5">
            {INDUSTRY_TAGS.map((tag) => (
              <TagChip
                key={tag}
                label={tag}
                active={filters.industry.includes(tag)}
                onClick={() => toggleFilter('industry', tag)}
                testId={`chip-industry-${tag}`}
              />
            ))}
          </div>
        </div>

        {/* Style */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-[#858585] font-mono w-20 shrink-0">Style:</span>
          <div className="flex flex-wrap gap-1.5">
            {STYLE_TAGS.map((tag) => (
              <TagChip
                key={tag}
                label={tag}
                active={filters.style.includes(tag)}
                onClick={() => toggleFilter('style', tag)}
                testId={`chip-style-${tag}`}
              />
            ))}
          </div>
        </div>

        {/* Sections */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-[#858585] font-mono w-20 shrink-0">Sections:</span>
          <div className="flex flex-wrap gap-1.5">
            {SECTION_TAGS.map((tag) => (
              <TagChip
                key={tag}
                label={tag}
                active={filters.sections.includes(tag)}
                onClick={() => toggleFilter('sections', tag)}
                testId={`chip-sections-${tag}`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Status Line */}
      <div className="flex justify-between items-center text-xs text-[#858585] font-mono">
        <span>
          Showing {filteredItems.length} of the loaded prompts
        </span>
        {hasMore && <span>Load more to search further.</span>}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {filteredItems.map((item) => (
          <LibraryCard key={item.id} item={item} />
        ))}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div className="flex justify-center pt-4">
          <button
            type="button"
            data-testid="btn-load-more"
            onClick={loadMore}
            disabled={status === 'loading'}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-8 py-3 rounded-[59px] inset-border transition-colors cursor-pointer flex items-center gap-2 disabled:opacity-50"
          >
            {status === 'loading' && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            Load more
          </button>
        </div>
      )}
    </div>
  );
};
