/**
 * S10 Public Share Page
 * Document 2, Section 4.9 & 5.11
 */
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Copy, Download, FileText, ArrowRight, Loader2 } from 'lucide-react';
import { getShare, getShareImages, incrementCopy } from '../storage/remote';
import { addCopiedShare, getCopiedShares } from '../storage/local';
import { ShareDoc, ShareImageDoc } from '../types';
import { MarkdownView } from '../components/MarkdownView';
import { Lightbox } from '../components/Lightbox';
import { useToast } from '../components/Toast';
import { slug } from '../services/render';

export const SharePage: React.FC = () => {
  const { shareId } = useParams<{ shareId: string }>();
  const { showToast } = useToast();

  const [share, setShare] = useState<ShareDoc | null>(null);
  const [images, setImages] = useState<ShareImageDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    let isMounted = true;
    async function loadShareData() {
      if (!shareId) return;
      setLoading(true);
      const docData = await getShare(shareId);
      if (isMounted && docData) {
        setShare(docData);
        const imgList = await getShareImages(shareId);
        if (isMounted) {
          // If images subcollection is empty but coverImage exists, use coverImage as fallback
          if (imgList.length === 0 && docData.coverImage) {
            setImages([
              {
                index: 0,
                mime: 'image/jpeg',
                width: 480,
                height: 300,
                dataUrl: docData.coverImage,
              },
            ]);
          } else {
            setImages(imgList);
          }
        }
      }
      if (isMounted) setLoading(false);
    }
    loadShareData();
    return () => {
      isMounted = false;
    };
  }, [shareId]);

  const handleCopy = async () => {
    if (!share || !shareId) return;
    try {
      await navigator.clipboard.writeText(share.markdown);
      showToast('Copied to clipboard');

      // Increment copy count if not copied before by this device
      const copiedList = await getCopiedShares();
      if (!copiedList.includes(shareId)) {
        await incrementCopy(shareId);
        await addCopiedShare(shareId);
      }
    } catch {
      showToast('Failed to copy');
    }
  };

  const handleDownload = () => {
    if (!share) return;
    const blob = new Blob([share.markdown], { type: 'text/markdown;charset=utf-8' });
    const filename = `${slug(share.title)}-design.md`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${filename}`);
  };

  const handleExportPdf = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="max-w-[1200px] mx-auto px-6 py-24 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#0063e1] animate-spin" />
      </div>
    );
  }

  if (!share) {
    return (
      <div className="max-w-md mx-auto px-6 py-24 text-center flex flex-col gap-4">
        <h2 className="text-xl font-normal text-white">Share Not Found</h2>
        <p className="text-sm text-[#858585]">
          This share link does not exist or may have been unlisted by its author.
        </p>
        <Link
          to="/"
          className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-sm px-6 py-2.5 rounded-[59px] inset-border transition-colors self-center"
        >
          Go Home
        </Link>
      </div>
    );
  }

  const allTags = [
    ...(share.tags.industry || []),
    ...(share.tags.style || []),
    ...(share.tags.sections || []),
  ];

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-8 flex flex-col gap-6 text-left">
      {/* Top Meta & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-6 no-print">
        <div className="flex flex-col gap-1.5">
          <span className="text-xs text-[#858585] font-mono">Shared with Loupe</span>
          <h1
            data-testid="share-title"
            className="text-2xl font-normal text-white tracking-[-0.027em]"
          >
            {share.title}
          </h1>

          <div className="flex flex-wrap gap-1.5 mt-1">
            {allTags.map((t) => (
              <span
                key={t}
                className="bg-[#1f1f1f] text-[#858585] text-xs font-mono px-2 py-0.5 rounded-[4px]"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleCopy}
            className="bg-[#0063e1] hover:bg-[#0052be] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            Copy
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download .md
          </button>
          <button
            type="button"
            onClick={handleExportPdf}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            Export PDF
          </button>
          <Link
            to="/generate"
            data-testid="btn-create-own"
            className="bg-[#1f1f1f] hover:bg-[#2b2c2e] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 ml-2"
          >
            Create your own
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Main Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8 items-start">
        {/* Images strip */}
        <aside className="flex flex-col gap-4 no-print">
          <span className="text-xs font-mono text-[#858585] uppercase tracking-wider">
            Screenshots ({images.length})
          </span>
          <div className="flex flex-row lg:flex-col gap-3 overflow-x-auto pb-2">
            {images.map((img, idx) => (
              <div
                key={idx}
                data-testid={`share-image-${idx}`}
                onClick={() => setLightboxIndex(idx)}
                className="w-28 lg:w-full h-24 lg:h-36 rounded-[12px] bg-[#040910] inset-border overflow-hidden shrink-0 cursor-pointer hover:border-[#0063e1] transition-all group flex items-center justify-center p-1"
              >
                <img
                  src={img.dataUrl}
                  alt={`Screenshot ${idx + 1}`}
                  className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                />
              </div>
            ))}
          </div>
        </aside>

        {/* Markdown document */}
        <div className="bg-[#0d0d0d] rounded-[16px] inset-border p-6 print-only-content min-w-0">
          <MarkdownView content={share.markdown} />
        </div>
      </div>

      {/* Lightbox */}
      {lightboxIndex !== null && (
        <Lightbox
          images={images}
          currentIndex={lightboxIndex}
          isOpen={lightboxIndex !== null}
          onClose={() => setLightboxIndex(null)}
          onPrev={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev - 1 + images.length) % images.length
            )
          }
          onNext={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev + 1) % images.length
            )
          }
        />
      )}
    </div>
  );
};
