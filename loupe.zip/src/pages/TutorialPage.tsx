/**
 * S11 Tutorial Page
 * Document 2, Section 4.10 & Document 1, Section 5.3
 */
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

export const TutorialPage: React.FC = () => {
  return (
    <div className="max-w-[800px] mx-auto px-6 py-12 flex flex-col gap-12 text-left">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-normal text-white tracking-[-0.027em]">
          How to Use Loupe
        </h1>
        <p className="text-base text-[#858585]">
          A guide to capturing clean screenshots and generating production-ready design specifications.
        </p>
      </div>

      {/* Step 1 */}
      <section className="flex flex-col gap-4 border-t border-[rgba(255,255,255,0.08)] pt-6">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full bg-[#1f1f1f] text-white flex items-center justify-center font-mono text-xs inset-border">
            1
          </div>
          <h2 className="text-xl font-normal text-white">
            Capturing high-fidelity screenshots
          </h2>
        </div>
        <p className="text-sm text-[#858585] leading-relaxed">
          For the most accurate design extraction, follow these capture guidelines:
        </p>
        <ul className="flex flex-col gap-2 text-sm text-[#858585]">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#0063e1] shrink-0 mt-0.5" />
            <span>Use desktop viewports (1440px width recommended, minimum 800px).</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#0063e1] shrink-0 mt-0.5" />
            <span>Avoid browser tabs, window frames, address bars, and developer tool panels.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#0063e1] shrink-0 mt-0.5" />
            <span>Capture consecutive sections from top to bottom (Hero, Features, Pricing, Footer).</span>
          </li>
        </ul>
      </section>

      {/* Step 2 */}
      <section className="flex flex-col gap-4 border-t border-[rgba(255,255,255,0.08)] pt-6">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full bg-[#1f1f1f] text-white flex items-center justify-center font-mono text-xs inset-border">
            2
          </div>
          <h2 className="text-xl font-normal text-white">
            Inspecting and extracting in Loupe
          </h2>
        </div>
        <p className="text-sm text-[#858585] leading-relaxed">
          Drop your screenshots into the generator. Loupe verifies resolution and sharpness, measures geometric color distributions, analyzes multi-site compositions, and constructs your complete design system.
        </p>
      </section>

      {/* Step 3 */}
      <section className="flex flex-col gap-4 border-t border-[rgba(255,255,255,0.08)] pt-6">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-full bg-[#1f1f1f] text-white flex items-center justify-center font-mono text-xs inset-border">
            3
          </div>
          <h2 className="text-xl font-normal text-white">
            Rebuilding in your AI code builder
          </h2>
        </div>
        <p className="text-sm text-[#858585] leading-relaxed">
          Copy the generated <span className="text-white font-mono text-xs">design.md</span> or download the file. Paste it directly as the first prompt into Claude, Cursor, v0, Bolt, or Gemini:
        </p>
        <div className="bg-[#040910] rounded-[12px] p-4 inset-border font-mono text-xs text-[#858585]">
          <span className="text-white">"Here is the exact design system specification to follow:</span>
          <br /><br />
          [Paste your design.md here]
          <br /><br />
          <span className="text-white">Please build the landing page according to these tokens and component specs."</span>
        </div>
      </section>

      <div className="pt-4">
        <Link
          to="/generate"
          className="inline-flex items-center gap-2 bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-6 py-3 rounded-[59px] transition-colors"
        >
          Start Generating
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
