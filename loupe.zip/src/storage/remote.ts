/**
 * Firestore remote storage adapter for shares and library
 * Document 2, Section 5.1, 5.7 & 5.11
 */
import { nanoid } from 'nanoid';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  increment,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  startAfter,
  writeBatch,
} from 'firebase/firestore';
import { getFirebaseDb, isFirebaseConfigured } from './firebase';
import { ShareDoc, ShareImageDoc, Result } from '../types';
import { getDeviceId } from '../services/identity';
import { COVER_MAX_BYTES, COVER_WIDTH, SHARE_IMAGE_MAX_BYTES } from '../config';
import { compressImage } from '../services/compress';

const SHARES_COLLECTION = 'shares';
const LOCAL_SHARES_KEY = 'loupe_mock_shares';
const LOCAL_IMAGES_PREFIX = 'loupe_mock_share_images_';

// Seed initial library items if empty so library has quality templates to browse out of the box
const SEED_LIBRARY_ITEMS: (ShareDoc & { id: string })[] = [
  {
    id: 'rekki-control',
    title: 'REKKI: Midnight Enterprise Control Room',
    markdown: `# DESIGN.md: REKKI
> Mission control dashboard in a darkroom

**Theme:** dark

REKKI is a midnight enterprise control room: a pitch-black canvas hosting dense product interfaces that glow from within.

## Tokens — Colors

| Name | Value | Token | Role |
|---|---|---|---|
| Signal Blue | \`#0063E1\` | \`--color-signal-blue\` | Primary CTA fill, active nav indicator |
| Obsidian | \`#000000\` | \`--color-obsidian\` | Page canvas, dominant background |
| Carbon | \`#040910\` | \`--color-carbon\` | Card surface base |
| Graphite | \`#0D0D0D\` | \`--color-graphite\` | Elevated card surfaces |
| Iron | \`#1F1F1F\` | \`--color-iron\` | Input field backgrounds |
| Steel | \`#2B2C2E\` | \`--color-steel\` | Highest card elevation, modal surfaces |
| Ash | \`#858585\` | \`--color-ash\` | Body text, muted labels |
| Paper | \`#FFFFFF\` | \`--color-paper\` | Light neutral text and headings |

## Tokens — Typography

### Primary Typeface: Diatype REKKI
- **Substitute:** Inter, system-ui
- **Role:** Display headlines and body text
- **Weights:** 400, 600
- **Token:** \`--font-primary\`

### Type Scale

| Role | Family | Weight | Size | Line Height | Letter Spacing | Token |
|---|---|---|---|---|---|---|
| display | Inter | 400 | 86px | 1.00 | -0.064em | \`--text-display\` |
| heading-lg | Inter | 400 | 56px | 1.25 | -0.040em | \`--text-heading-lg\` |
| heading | Inter | 400 | 24px | 1.33 | -0.027em | \`--text-heading\` |
| body | Inter | 400 | 16px | 1.50 | -0.007em | \`--text-body\` |

## Tokens — Spacing & Shapes

- **Base unit:** 4px
- **Density:** comfortable

### Border Radius

| Element | Value |
|---|---|
| buttons | 59px |
| cards | 16px |
| largeCards | 30px |
| inputs | 8px |
`,
    tags: {
      industry: ['developer-tools', 'saas'],
      style: ['dark', 'monochrome', 'enterprise'],
      sections: ['hero', 'dashboard', 'features'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23040910"/%3E%3Crect x="24" y="24" width="432" height="60" rx="12" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3Ccircle cx="56" cy="54" r="14" fill="%230063e1"/%3E%3Crect x="84" y="48" width="120" height="12" rx="6" fill="%23ffffff"/%3E%3Crect x="24" y="104" width="206" height="172" rx="16" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3Crect x="250" y="104" width="206" height="172" rx="16" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3C/svg%3E',
    deviceId: 'system_curated',
    createdAt: Date.now() - 86400000 * 2,
    copyCount: 42,
    visibility: 'public',
    publicAt: Date.now() - 86400000 * 2,
    publicCopyCount: 42,
  },
  {
    id: 'aeline-ai',
    title: 'Aeline: AI Consulting Landing',
    markdown: `# DESIGN.md: Aeline
> High-touch AI advisory and systems engineering

**Theme:** dark

## Tokens — Colors

| Name | Value | Token | Role |
|---|---|---|---|
| Signal Blue | \`#0063E1\` | \`--color-signal-blue\` | Primary CTA fill |
| Pitch Black | \`#000000\` | \`--color-canvas\` | Main canvas background |
| Surface Iron | \`#1F1F1F\` | \`--color-surface\` | Card container background |
| Text Ash | \`#858585\` | \`--color-muted\` | Secondary text |
| Paper White | \`#FFFFFF\` | \`--color-primary\` | Heading text |

## Tokens — Spacing & Shapes

- **Base unit:** 4px
- **Density:** comfortable

### Border Radius

| Element | Value |
|---|---|
| buttons | 59px |
| cards | 16px |
| inputs | 8px |
`,
    tags: {
      industry: ['ai-tech', 'agency'],
      style: ['dark', 'minimal'],
      sections: ['hero', 'features', 'cta'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23000000"/%3E%3Crect x="30" y="40" width="420" height="80" rx="16" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3Ccircle cx="70" cy="80" r="16" fill="%230063e1"/%3E%3Crect x="105" y="74" width="160" height="12" rx="6" fill="%23ffffff"/%3E%3Crect x="30" y="140" width="420" height="120" rx="16" fill="%231f1f1f"/%3E%3C/svg%3E',
    deviceId: 'system_curated',
    createdAt: Date.now() - 86400000,
    copyCount: 19,
    visibility: 'public',
    publicAt: Date.now() - 86400000,
    publicCopyCount: 19,
  },
  {
    id: 'northfield-fintech',
    title: 'Northfield: Fintech Pricing Page',
    markdown: `# DESIGN.md: Northfield
> Transparent infrastructure pricing for algorithmic traders

**Theme:** dark

## Tokens — Colors

| Name | Value | Token | Role |
|---|---|---|---|
| Accent Blue | \`#0063E1\` | \`--color-accent\` | Selection & active tier |
| Canvas Dark | \`#000000\` | \`--color-canvas\` | Page floor |
| Surface Card | \`#0D0D0D\` | \`--color-card\` | Tier card background |
| Ash Text | \`#858585\` | \`--color-ash\` | Feature list muted text |

## Tokens — Spacing & Shapes

- **Base unit:** 4px
- **Density:** comfortable

### Border Radius

| Element | Value |
|---|---|
| buttons | 59px |
| cards | 16px |
| inputs | 8px |
`,
    tags: {
      industry: ['fintech', 'saas'],
      style: ['dark', 'enterprise'],
      sections: ['pricing', 'faq'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23040910"/%3E%3Crect x="30" y="40" width="130" height="220" rx="16" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3Crect x="175" y="30" width="130" height="240" rx="16" fill="%230d0d0d" stroke="%230063e1" stroke-width="2"/%3E%3Crect x="320" y="40" width="130" height="220" rx="16" fill="%230d0d0d" stroke="%232b2c2e" stroke-width="1"/%3E%3C/svg%3E',
    deviceId: 'system_curated',
    createdAt: Date.now() - 43200000,
    copyCount: 27,
    visibility: 'public',
    publicAt: Date.now() - 43200000,
    publicCopyCount: 27,
  },
];

function getLocalShares(): (ShareDoc & { id: string })[] {
  if (typeof localStorage === 'undefined') return [...SEED_LIBRARY_ITEMS];
  try {
    const raw = localStorage.getItem(LOCAL_SHARES_KEY);
    if (!raw) {
      localStorage.setItem(LOCAL_SHARES_KEY, JSON.stringify(SEED_LIBRARY_ITEMS));
      return [...SEED_LIBRARY_ITEMS];
    }
    return JSON.parse(raw);
  } catch {
    return [...SEED_LIBRARY_ITEMS];
  }
}

function saveLocalShares(shares: (ShareDoc & { id: string })[]) {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(LOCAL_SHARES_KEY, JSON.stringify(shares));
  } catch (err) {
    console.warn('Local share sync warning:', err);
  }
}

export function isRemoteAvailable(): boolean {
  // Always true because of the high-fidelity mock sync fallback or live Firestore
  return true;
}

export async function createShare(
  result: Result,
  coverDataUrl: string,
  images: { width: number; height: number; dataUrl: string; mime?: string }[]
): Promise<string> {
  const shareId = nanoid(12);
  const db = getFirebaseDb();

  const shareDoc: ShareDoc = {
    title: result.title,
    markdown: result.markdown,
    tags: result.tags,
    imageCount: images.length,
    coverImage: coverDataUrl,
    deviceId: getDeviceId(),
    createdAt: db ? serverTimestamp() : Date.now(),
    copyCount: 0,
    visibility: 'unlisted',
  };

  if (db) {
    try {
      const batch = writeBatch(db);
      const shareRef = doc(db, SHARES_COLLECTION, shareId);
      batch.set(shareRef, shareDoc);

      const imagesCol = collection(db, SHARES_COLLECTION, shareId, 'images');
      images.forEach((img, idx) => {
        const imgRef = doc(imagesCol, String(idx));
        const imgDoc: ShareImageDoc = {
          index: idx,
          mime: img.mime || 'image/jpeg',
          width: img.width,
          height: img.height,
          dataUrl: img.dataUrl,
        };
        batch.set(imgRef, imgDoc);
      });

      await batch.commit();
      return shareId;
    } catch (err) {
      console.warn('Firestore write failed, falling back to local share:', err);
    }
  }

  // Fallback to local storage share
  const localShares = getLocalShares();
  localShares.unshift({ ...shareDoc, id: shareId, createdAt: Date.now() });
  saveLocalShares(localShares);

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(
        `${LOCAL_IMAGES_PREFIX}${shareId}`,
        JSON.stringify(
          images.map((img, idx) => ({
            index: idx,
            mime: img.mime || 'image/jpeg',
            width: img.width,
            height: img.height,
            dataUrl: img.dataUrl,
          }))
        )
      );
    } catch (e) {
      console.warn('Image storage warning:', e);
    }
  }

  return shareId;
}

export async function getShare(shareId: string): Promise<ShareDoc | null> {
  const db = getFirebaseDb();
  if (db) {
    try {
      const shareRef = doc(db, SHARES_COLLECTION, shareId);
      const snap = await getDoc(shareRef);
      if (snap.exists()) {
        return snap.data() as ShareDoc;
      }
    } catch (err) {
      console.warn('Firestore read error:', err);
    }
  }

  const localShares = getLocalShares();
  const found = localShares.find(s => s.id === shareId);
  return found || null;
}

export async function getShareImages(shareId: string): Promise<ShareImageDoc[]> {
  const db = getFirebaseDb();
  if (db) {
    try {
      const imagesCol = collection(db, SHARES_COLLECTION, shareId, 'images');
      const snap = await getDocs(imagesCol);
      if (!snap.empty) {
        return snap.docs.map(d => d.data() as ShareImageDoc).sort((a, b) => a.index - b.index);
      }
    } catch (err) {
      console.warn('Firestore images error:', err);
    }
  }

  if (typeof localStorage !== 'undefined') {
    try {
      const raw = localStorage.getItem(`${LOCAL_IMAGES_PREFIX}${shareId}`);
      if (raw) return JSON.parse(raw);
    } catch {}
  }

  return [];
}

export async function setPublic(shareId: string, isPublic: boolean): Promise<void> {
  const db = getFirebaseDb();
  if (db) {
    try {
      const shareRef = doc(db, SHARES_COLLECTION, shareId);
      if (isPublic) {
        const currentDoc = await getDoc(shareRef);
        const copyCount = currentDoc.exists() ? currentDoc.data()?.copyCount || 0 : 0;
        await updateDoc(shareRef, {
          visibility: 'public',
          publicAt: serverTimestamp(),
          publicCopyCount: copyCount,
        });
      } else {
        await updateDoc(shareRef, {
          visibility: 'unlisted',
          publicAt: null,
          publicCopyCount: null,
        });
      }
      return;
    } catch (err) {
      console.warn('Firestore setPublic error:', err);
    }
  }

  const localShares = getLocalShares();
  const idx = localShares.findIndex(s => s.id === shareId);
  if (idx !== -1) {
    if (isPublic) {
      localShares[idx].visibility = 'public';
      localShares[idx].publicAt = Date.now();
      localShares[idx].publicCopyCount = localShares[idx].copyCount;
    } else {
      localShares[idx].visibility = 'unlisted';
      delete localShares[idx].publicAt;
      delete localShares[idx].publicCopyCount;
    }
    saveLocalShares(localShares);
  }
}

export async function listPublic(options: {
  sort?: 'new' | 'copied';
  pageSize?: number;
  cursor?: any;
}): Promise<{ items: (ShareDoc & { id: string })[]; hasMore: boolean; nextCursor?: any }> {
  const pageSize = options.pageSize || 24;
  const db = getFirebaseDb();

  if (db) {
    try {
      const sharesCol = collection(db, SHARES_COLLECTION);
      const orderField = options.sort === 'copied' ? 'publicCopyCount' : 'publicAt';
      let q = query(
        sharesCol,
        where('visibility', '==', 'public'),
        orderBy(orderField, 'desc'),
        limit(pageSize + 1)
      );

      if (options.cursor) {
        q = query(q, startAfter(options.cursor));
      }

      const snap = await getDocs(q);
      const docs = snap.docs;
      const hasMore = docs.length > pageSize;
      const trimmed = hasMore ? docs.slice(0, pageSize) : docs;
      const nextCursor = trimmed.length > 0 ? trimmed[trimmed.length - 1] : undefined;

      const items = trimmed.map(d => ({
        ...(d.data() as ShareDoc),
        id: d.id,
      }));

      return { items, hasMore, nextCursor };
    } catch (err) {
      console.warn('Firestore listPublic error:', err);
    }
  }

  // Local fallback
  const localShares = getLocalShares().filter(s => s.visibility === 'public');
  if (options.sort === 'copied') {
    localShares.sort((a, b) => (b.copyCount || 0) - (a.copyCount || 0));
  } else {
    localShares.sort((a, b) => {
      const timeA = typeof a.createdAt === 'number' ? a.createdAt : 0;
      const timeB = typeof b.createdAt === 'number' ? b.createdAt : 0;
      return timeB - timeA;
    });
  }

  const offset = options.cursor ? parseInt(String(options.cursor), 10) : 0;
  const paged = localShares.slice(offset, offset + pageSize);
  const hasMore = offset + pageSize < localShares.length;
  const nextCursor = hasMore ? offset + pageSize : undefined;

  return { items: paged, hasMore, nextCursor };
}

export async function incrementCopy(shareId: string): Promise<void> {
  const db = getFirebaseDb();
  if (db) {
    try {
      const shareRef = doc(db, SHARES_COLLECTION, shareId);
      await updateDoc(shareRef, {
        copyCount: increment(1),
        publicCopyCount: increment(1),
      });
      return;
    } catch (err) {
      console.warn('Firestore incrementCopy error:', err);
    }
  }

  const localShares = getLocalShares();
  const idx = localShares.findIndex(s => s.id === shareId);
  if (idx !== -1) {
    localShares[idx].copyCount = (localShares[idx].copyCount || 0) + 1;
    if (localShares[idx].publicCopyCount !== undefined) {
      localShares[idx].publicCopyCount = (localShares[idx].publicCopyCount || 0) + 1;
    }
    saveLocalShares(localShares);
  }
}
