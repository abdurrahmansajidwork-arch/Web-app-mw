/**
 * Local storage adapter for IndexedDB (idb-keyval)
 * Database name: 'loupe'
 * Stores: 'results', 'cache', 'meta'
 * Document 2, Section 5.7
 */
import { createStore, get, set, del, entries } from 'idb-keyval';
import { HISTORY_MAX } from '../config';
import { Result, SiteGroup } from '../types';

// Create stores inside 'loupe' database
const resultsStore = typeof window !== 'undefined' ? createStore('loupe-db', 'results') : null;
const cacheStore = typeof window !== 'undefined' ? createStore('loupe-db', 'cache') : null;
const metaStore = typeof window !== 'undefined' ? createStore('loupe-db', 'meta') : null;

// In-memory fallback for Node / SSR
const memoryResults = new Map<string, Result>();
const memoryCache = new Map<string, string>();
const memoryMeta = new Map<string, any>();

export async function saveResult(result: Result): Promise<void> {
  if (resultsStore) {
    await set(result.id, result, resultsStore);
    if (result.cacheKey && cacheStore) {
      await set(result.cacheKey, result.id, cacheStore);
    }

    // Prune history if it exceeds HISTORY_MAX
    const all = await entries(resultsStore);
    if (all.length > HISTORY_MAX) {
      // Sort by createdAt ascending to find oldest
      const sorted = (all as [string, Result][]).sort((a, b) => a[1].createdAt - b[1].createdAt);
      const toRemoveCount = all.length - HISTORY_MAX;
      for (let i = 0; i < toRemoveCount; i++) {
        const [oldId, oldResult] = sorted[i];
        await del(oldId, resultsStore);
        if (oldResult.cacheKey && cacheStore) {
          await del(oldResult.cacheKey, cacheStore);
        }
      }
    }
  } else {
    memoryResults.set(result.id, result);
    if (result.cacheKey) {
      memoryCache.set(result.cacheKey, result.id);
    }
  }
}

export async function getResult(id: string): Promise<Result | undefined> {
  if (resultsStore) {
    return await get<Result>(id, resultsStore);
  }
  return memoryResults.get(id);
}

export async function deleteResult(id: string): Promise<void> {
  if (resultsStore) {
    const res = await get<Result>(id, resultsStore);
    if (res && res.cacheKey && cacheStore) {
      await del(res.cacheKey, cacheStore);
    }
    await del(id, resultsStore);
  } else {
    const res = memoryResults.get(id);
    if (res && res.cacheKey) {
      memoryCache.delete(res.cacheKey);
    }
    memoryResults.delete(id);
  }
}

export async function listResults(): Promise<Result[]> {
  if (resultsStore) {
    const all = await entries<string, Result>(resultsStore);
    return all.map(([_, v]) => v).sort((a, b) => b.createdAt - a.createdAt);
  }
  return Array.from(memoryResults.values()).sort((a, b) => b.createdAt - a.createdAt);
}

export async function getCachedResultId(cacheKey: string): Promise<string | undefined> {
  if (cacheStore) {
    return await get<string>(cacheKey, cacheStore);
  }
  return memoryCache.get(cacheKey);
}

export async function getSiteQueue(): Promise<SiteGroup[]> {
  if (metaStore) {
    const queue = await get<SiteGroup[]>('siteQueue', metaStore);
    return queue || [];
  }
  return memoryMeta.get('siteQueue') || [];
}

export async function setSiteQueue(queue: SiteGroup[]): Promise<void> {
  if (metaStore) {
    await set('siteQueue', queue, metaStore);
  } else {
    memoryMeta.set('siteQueue', queue);
  }
}

export async function getCopiedShares(): Promise<string[]> {
  if (metaStore) {
    const list = await get<string[]>('copiedShares', metaStore);
    return list || [];
  }
  return memoryMeta.get('copiedShares') || [];
}

export async function addCopiedShare(shareId: string): Promise<void> {
  const current = await getCopiedShares();
  if (!current.includes(shareId)) {
    const updated = [...current, shareId];
    if (metaStore) {
      await set('copiedShares', updated, metaStore);
    } else {
      memoryMeta.set('copiedShares', updated);
    }
  }
}
