/**
 * Configuration and constants for Loupe
 * Document 2, Section 5.3
 */

export const APP_NAME = 'Loupe';
export const TAGLINE = 'See the design. Rebuild it exactly.';
export const PIPELINE_VERSION = '1.0.0';

// Gemini model id - pinned from AI Studio model picker
export const GEMINI_MODEL = 'gemini-3.8-flash';

export const GEN_CONFIG = {
  temperature: 0,
  topK: 1,
  seed: 42,
  maxOutputTokens: 16000,
};

export const MAX_FILES = 8;
export const MAX_FILE_MB = 10;
export const MIN_WIDTH = 800;
export const MIN_HEIGHT = 300;
export const MAX_DIM = 12000;
export const BLUR_THRESHOLD = 40;
export const MAX_SEGMENTS = 12;
export const SEGMENT_RATIO = 1.25;
export const TALL_RATIO = 2.2;
export const AI_MAX_SIDE = 2048;
export const AI_JPEG_QUALITY = 0.9;
export const RETRY_DELAYS_MS = [5000, 15000, 30000];
export const CALL_TIMEOUT_MS = 90000;
export const SCHEMA_RETRIES = 2;
export const COLOR_SNAP_DISTANCE = 40;
export const COLOR_MERGE_DISTANCE = 24;
export const HISTORY_MAX = 50;
export const SHARE_IMAGE_MAX_BYTES = 600000;
export const COVER_WIDTH = 480;
export const COVER_MAX_BYTES = 50000;
export const LIBRARY_FIRST_PAGE = 48;
export const LIBRARY_PAGE = 24;
export const AUTH_ENABLED = false;
export const PAYMENTS_ENABLED = false;

// Standard controlled vocabularies for tagging
export const INDUSTRY_TAGS = [
  'ai-tech',
  'saas',
  'fintech',
  'agency',
  'e-commerce',
  'developer-tools',
  'portfolio',
  'crypto-web3',
  'health-wellness',
  'media-editorial',
] as const;

export const STYLE_TAGS = [
  'dark',
  'light',
  'minimal',
  'enterprise',
  'retro-cyber',
  'playful',
  'monochrome',
  'brutalist',
  'high-contrast',
] as const;

export const SECTION_TAGS = [
  'hero',
  'pricing',
  'features',
  'faq',
  'testimonials',
  'navigation',
  'footer',
  'cta',
  'dashboard',
  'form',
] as const;

export const ANALYZE_PROMPT = `You are Loupe's screenshot inspection engine.
Analyze the provided website screenshot(s) carefully.

TASK:
1. Verify if the provided images are legitimate screenshots of a website or web application interface. If any image is not a website (e.g. animal, personal photo, drawing, physical object, wallpaper) or contains adult/unsafe material, mark isWebsite as false with the appropriate rejection code.
2. Determine if the screenshots belong to ONE website or MULTIPLE different websites.
3. Group the screenshots by website. For each website group:
   - id: a unique short slug (e.g. "site-1", "aeline-ai")
   - label: concise descriptive label in the format "<Brand/Site name>: <Type of site>" (e.g. "Aeline: AI consulting landing page", "Northfield: Fintech pricing page")
   - description: 1 short sentence summarizing what the site is
   - sections: array of detected section types (e.g. ["hero", "features", "pricing", "faq"])
   - imageIndices: array of 0-based indices corresponding to the input images belonging to this site (e.g. [0, 1])

REJECTION CODES IF INVALID:
- 'not_website': image is not a website screenshot (photos, scenery, animals, memes)
- 'adult_or_unsafe': contains adult, NSFW, or unsafe content
- 'unreadable': image is too distorted, blurry, or low resolution to inspect UI details

Return ONLY valid JSON matching this schema:
{
  "isWebsite": boolean,
  "rejectionCode": string | null,
  "rejectionReason": string | null,
  "sites": [
    {
      "id": string,
      "label": string,
      "description": string,
      "sections": string[],
      "imageIndices": number[]
    }
  ]
}`;

export const EXTRACT_PROMPT = `You are Loupe's precision design system extractor.
Your job is to look closely at the provided website screenshot(s) and measured palette, and extract an exhaustive, accurate design specification into structured JSON.

PRECISION GUIDELINES:
1. Examine the visual hierarchy: background floor, elevated card surfaces, input fields, modals.
2. Identify brand typography: display/headline fonts, body font, utility/mono font, weight patterns (note if headlines are whisper-weight/light or bold), exact negative or positive tracking.
3. Identify color tokens: background, surface layers, primary CTA color, text colors (high contrast heading, body text, muted labels, hairline borders).
4. Measure spacing and shapes: base spacing unit (usually 4px or 8px), border radii for buttons, cards, images, inputs, and elevation shadows/borders.
5. Component specs: analyze the primary CTA button (radius, padding, font, colors), navigation, standard cards, text inputs, status tags/pills.
6. Provide concrete, actionable Do's and Don'ts directly observed from the design (no generic filler).

Do not output raw Markdown. Output ONLY a structured JSON object strictly conforming to the requested schema.`;
